basket_a = {'apple', 'banana', 'apricot', 'orange'}
basket_b = {'apple', 'water melon', 'peach', 'berries'}

print("union =", basket_a | basket_b)
print("intersection =", basket_a & basket_b)
print("difference =", basket_a - basket_b)
print("symmetric difference =", basket_a ^ basket_b)
