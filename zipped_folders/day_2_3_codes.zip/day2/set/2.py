av = ["rr", "tt"]
bv = ["rr", "xx"]

#set_a = {"gg", av, bv, "ee", "ww"}
set_a = {"gg", ["rr", "tt"], ["rr", "xx"], "ee", "ww"}

#bv[1] = "tt"

#set_a = {"gg", ["rr", "tt"], ["rr", "tt"], "ee", "ww"}

#print(set_a)
