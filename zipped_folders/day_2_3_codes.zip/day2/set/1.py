basket_a = {"banana", "orange", "berries", "banana", "apple", "apricot", "orange"}
basket_b = {"peach", "mango", "fig", "dragon fruit"}

print(basket_a)
print(basket_b)
