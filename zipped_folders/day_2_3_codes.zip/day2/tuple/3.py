avengers = ('Hulk', ['THOR', 'hawkeye', 'black widow'], 'captain')
avengers[1][1] = "Dr Strange"

# error
avengers[1][1][1] = "R"
avengers[1] = "Dr Strange"
