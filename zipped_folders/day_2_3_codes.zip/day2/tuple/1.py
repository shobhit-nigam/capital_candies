ave = ['Hulk', 'THOR', 'hawkeye', 'black widow', 'captain']
avengers = ('Hulk', 'THOR', 'hawkeye', 'black widow', 'captain')

print("type of ave =", type(ave))
print("type of avengers =", type(avengers))
