ave = ['Hulk', 'THOR', 'hawkeye', 'black widow', 'captain']
avengers = ('Hulk', 'THOR', 'hawkeye', 'black widow', 'captain')
nums = (12.35, 78.90)

ave[0] = 'HULK'
print(ave)
# error
avengers[0] = 'HULK'
