avengers = {"ironman":"suit", "hawkeye":"arrows", "captain":"shield", "thor":"hammer"}

print("avengers =", avengers)
print("avengers['captain'] =", avengers["captain"])

