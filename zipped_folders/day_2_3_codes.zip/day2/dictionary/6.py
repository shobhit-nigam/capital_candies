avengers = {"ironman":"suit", "hawkeye":"arrows", "captain":["shield", "hammer"], "thor":"hammer"}

print(avengers.values())
print("-"*10)
list_val = list(avengers.values())

print(list_val)
