ave_a = {"ironman", "hawkeye", "captain", "thor"}

ave_b = {"ironman":"suit", "hawkeye":"arrows", "captain":"shield", "thor":"hammer"}


