avengers = {"ironman":"suit", "hawkeye":"arrows", "captain":"shield", "thor":"hammer"}

print("avengers =", avengers)
print("-------")

avengers['captain'] = ['shield', 'hammer']
avengers['hulk'] = 'smash'

print("avengers =", avengers)

avengers['captain'].append("cowl")

print("-------")
print("avengers =", avengers)

