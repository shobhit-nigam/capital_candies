avengers = {"ironman":"suit", "hawkeye":"arrows", "captain":["shield", "hammer"], "thor":"hammer"}

print(avengers.items())
