ave = ['Hulk', 'THOR', 'hawkeye', 'black widow', 'captain']

x = "".join(ave)
print(x)
