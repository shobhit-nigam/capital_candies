lista = ["ironman", "captain", "Hulk", "THOR", "black widow"]

print("lista =", lista)
lista.sort()
print("after sorting")
print("lista =", lista)
