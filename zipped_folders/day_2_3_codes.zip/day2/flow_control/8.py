lista = ['aa', 'hh', 'gg', 'aa', 'tt', 'cc', 'ee', 'aa']

for val in "hello":
    print("val =", val)




