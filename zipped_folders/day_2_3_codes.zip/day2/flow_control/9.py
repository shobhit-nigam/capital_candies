avengers = {'ironman': 'suit', 'hawkeye': 'arrows', 'captain': 'shield', 'thor': 'hammer'}

for x in avengers:
    print("x =", x)

print("------")

for x in avengers.values():
    print("x =", x)


