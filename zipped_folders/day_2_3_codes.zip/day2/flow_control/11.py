# lista = ['aa', 'hh', 'gg', 'aa', 'tt', 'cc', 'ee', 'aa']

for i in range(4):
    print("i =", i)


