avengers = {'ironman': 'suit', 'hawkeye': 'arrows', 'captain': 'shield', 'thor': 'hammer'}

for k, v in avengers.items():
    print("k =", k)
    print("v =", v)
    print("-------")


