
for i in range(2, 6):
    print("i =", i)


for val in range(4, 9):
    print("val =", val)

