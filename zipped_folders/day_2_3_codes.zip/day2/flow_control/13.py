
for i in range(1, 9, 2):
    print("i =", i)


