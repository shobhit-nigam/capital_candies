age = int(input("enter age:\n"))

while (age < 18):
    print(f"grow up soon, you are {age} years old")
    age = age + 1

print("------")
print("oh you are a grown up now")

    
