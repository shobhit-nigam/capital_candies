age = int(input("enter age:\n"))

if age < 18:
    print("have a cold coffee & cheerios probably")
    # some code
elif age >= 18 or age < 40:
    print("have your wine, but show the id")
elif age >=40:
    print("go enjoy, but pay the mortgages")
else:
    print("are you even human")

print("next part of code continues")
