lista = ['aa', 'hh', 'gg', 'aa', 'tt', 'cc', 'ee', 'aa']

for val in lista:
    if val == "tt":
        print("hey found tt")
        break
    else:
        print("val =", val)




