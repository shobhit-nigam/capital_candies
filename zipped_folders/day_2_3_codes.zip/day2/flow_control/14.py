
for i in range(6, 2, -1):
    print("i =", i)


