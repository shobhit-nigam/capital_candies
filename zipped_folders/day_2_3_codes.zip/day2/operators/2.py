lista = ['aa', 'hh', 'gg', 'aa', 'tt', 'cc', 'ee', 'aa']

print(type(lista) is list)



