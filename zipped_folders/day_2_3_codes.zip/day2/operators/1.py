lista = ['aa', 'hh', 'gg', 'aa', 'tt', 'cc', 'ee', 'aa']

print("zz" in lista)



