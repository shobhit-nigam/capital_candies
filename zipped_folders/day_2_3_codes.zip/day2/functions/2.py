lista = ['berries', 'apricot', 'apple', 'orange', 'peach', 'banana']
listb = [0, [], 0.0, False, None]
listc = [33, 45, 78, 10, 22, 0, 31]

print(any(lista))
print(any(listb))
print(any(listc))
