lista = ['berries', 'apricot', 'apple', 'orange', 'peach', 'banana']

print(len(lista))
