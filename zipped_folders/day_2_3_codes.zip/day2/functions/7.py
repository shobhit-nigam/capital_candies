y = 100
x = eval(input("plz enter only a number\n"))

print(type(x))

