x = int(input("plz enter only a number\n"))

print(x)
print(type(x))

