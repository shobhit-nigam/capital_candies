x = input()

print(x)
print(type(x))

