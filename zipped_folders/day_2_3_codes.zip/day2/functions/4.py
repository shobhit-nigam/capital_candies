lista = ['berries', 'apricot', 'apple', 'orange', 'peach', 'banana']

stra = "2345"
ia = 65781

ib = int(stra)

print(type(ib))

tupa = tuple(lista)

print(type(tupa))
