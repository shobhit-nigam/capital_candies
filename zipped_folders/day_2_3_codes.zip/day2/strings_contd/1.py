got = "valar morghulis valar dohaeris"
stra = got.split()
print(stra)

# stra is a list
