ave = "captain:shield-ironman:suit-wanda:magic"
lista = ave.split("-")
print(lista)

# lista is a list
