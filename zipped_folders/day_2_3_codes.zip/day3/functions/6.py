print("hello", end=", ")
print("nice dp", end=", ")
print("good bye")
    

    
    


