def funca(la, lb, lc):
    print("la =", la)
    print("lb =", lb)
    print("lc =", lc)
    


    
    


