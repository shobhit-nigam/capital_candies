def funca(la=11, lb=22, lc=33):
    # some code
    return la+lb, la*lb, [la, lb, lc]
    
    
x, y, z = funca()
# x, y, z = 33, 242, [11, 22, 33]

print("x =",x)
print("y =",y)
print("z =",z)

