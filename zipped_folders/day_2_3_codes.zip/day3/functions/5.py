def funca(la=11, lb=22, lc=33):
    print("la =", la)
    print("lb =", lb)
    print("lc =", lc)
    

    
    


