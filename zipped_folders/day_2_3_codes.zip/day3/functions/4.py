def funca(la, lb=22, lc=33):
    print("la =", la)
    print("lb =", lb)
    print("lc =", lc)
    
# default values to the right most

    
    


