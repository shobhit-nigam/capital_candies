def greet():
    print("howdy")
    print("hola")



    
    


