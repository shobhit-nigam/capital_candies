def greet():
    print("howdy")
    print("hola")

def greet():
    print("howdy")
    print("hola")
    print("namaste")

greet = 10


    
    


