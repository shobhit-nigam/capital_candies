import pandas as pd

dfa = pd.read_csv("annual.csv")

print(dfa)
