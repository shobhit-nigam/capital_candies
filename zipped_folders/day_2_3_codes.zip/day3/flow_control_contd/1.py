lista = ["aa", "vv", "gg", "aa", "tt", "vv", "aa", "rr", "ee", "tt"]


for x in lista[::2]:
    print("x =", x)
