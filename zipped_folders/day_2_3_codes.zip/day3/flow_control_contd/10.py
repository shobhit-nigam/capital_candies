for i in range(3):
    for j in range(3):
        print("i = ", i, " j = ", j)
        if i == j:
            break


    
    


