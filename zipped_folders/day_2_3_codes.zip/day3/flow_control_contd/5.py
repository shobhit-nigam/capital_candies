lista = ["aa", "vv", "gg", "aa", "tt", "vv", "aa", "rr", "ee", "tt"]

for i in range(len(lista)):
    print("lista[i] =", lista[i])
    


