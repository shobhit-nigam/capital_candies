lista = ["aa", "vv", "gg", "aa", "tt", "vv", "aa", "rr", "ee", "tt"]

list_aa = []

for i in range(len(lista)):
    if lista[i] == "aa":
        list_aa.append(i)

        
    print(list_aa)
    
    


