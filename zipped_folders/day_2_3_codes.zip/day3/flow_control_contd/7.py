lista = ["aa", "vv", "gg", "aa", "tt", "vv", "aa", "rr", "ee", "tt"]

list_aa = []

for i in range(len(lista)):
    if lista[i] == "aa":
        print(i)
    
    


