#lista = ["aa", "vv", "gg", "aa", "tt", "vv", "aa", "rr", "ee", "tt"]


for x in range(2, 15, 3):
    print("x =", x)

for x in range(15, 2, -2):
    print("x =", x)


