import os

print(os.getcwd())

