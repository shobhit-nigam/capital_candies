fa = open("books.txt", "r")

lista = fa.readlines()
print(lista)
fa.close()
