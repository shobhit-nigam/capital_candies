fa = open("books.txt", "r")

# UTF-8

stra = fa.read(5)
print(stra)


fa.close()
