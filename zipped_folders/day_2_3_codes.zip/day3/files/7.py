fa = open("data.txt", "w")

fa.write("hunger games" + "\n")
fa.write("starving games")
fa.close()


