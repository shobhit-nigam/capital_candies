fa = open("books.txt", "r")

stra = fa.read()
print(stra)

fa.close()
