with open("books.txt", "r") as fa:
    lista = fa.readlines()
    
print(lista)
