berries = 8
parts = 4

# so each berries had 4 parts
# comments

total = berries * parts

name = "chelsea" 

print(name, "had", total, "pieces")

"""
print(name, "had", berries, "pieces")
print(name, "had", oranges, "pieces")
print(name, "had", berries "pieces")
"""
