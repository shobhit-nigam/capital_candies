print("howdy")
print(11 + 30)

apples = 10

print(apples)
print(oranges)
print("its hot in here")
