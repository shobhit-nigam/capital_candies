x = y = z = 100

#x = "y"

print("x =", x)
print("y =", y)
print("z =", z)

x = 110
print("after changing the value of x")

print("x =", x)
print("y =", y)
print("z =", z)

