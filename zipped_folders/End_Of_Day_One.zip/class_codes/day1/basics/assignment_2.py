# multiple assignment
# each of the data gets assigned to the variables correspondingly
x, y, z = 100, 23.5, "hello there"

print("x =", x)
print("y =", y)
print("z =", z)
