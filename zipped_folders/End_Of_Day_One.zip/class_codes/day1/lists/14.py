# functions
avengers = ["ironman", "hawkeye", "Dr Strange", "black widow", "thor"]
marvel = ["mystique", "magneto"]

print("avengers =", avengers)
avengers.reverse()
print("after reversing")
print("avengers =", avengers)




