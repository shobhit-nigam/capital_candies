avengers = ["ironman", "hawkeye", "black widow", "thor"]
marvel = ["wolverine", "mystique", avengers]
print("avengers =", avengers)
print("marvel =", marvel)







