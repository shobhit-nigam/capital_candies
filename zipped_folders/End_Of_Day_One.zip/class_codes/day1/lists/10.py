# functions
avengers = ["ironman", "hawkeye", "Dr Strange", "black widow", "thor"]

print("avengers =", avengers)
print("-------")
avengers.remove("ironman")
print("avengers =", avengers)





