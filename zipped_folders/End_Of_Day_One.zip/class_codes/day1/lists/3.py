avengers = ["ironman", "hawkeye", "black widow", "thor"]
print(avengers)
print(avengers[2])
print(avengers[2][2])




list_num = [23, 43, 12,      67, 55]



