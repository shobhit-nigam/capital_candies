avengers = ["ironman", "hawkeye", "black widow", "thor"]
print(type(avengers))

