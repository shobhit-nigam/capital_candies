# functions
avengers = ["ironman", "hawkeye", "black widow", "thor"]

print("avengers =", avengers)
print("-------")
avengers.insert(2, "Dr Strange")

print("avengers =", avengers)





