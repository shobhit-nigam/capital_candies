avengers = ["ironman", "hawkeye", "black widow", "thor"]
marvel = ["wolverine", "mystique", avengers]

print("marvel =", marvel)
print("marvel[2] =", marvel[2])
print("marvel[2][1] =", marvel[2][1])
print("marvel[2][1][2] =", marvel[2][1][2])






