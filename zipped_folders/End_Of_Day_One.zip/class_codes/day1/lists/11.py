# functions
avengers = ["ironman", "hawkeye", "Dr Strange", "black widow", "thor"]

print("avengers =", avengers)
print("-------")
avengers.pop(2)
print("avengers =", avengers)
print("-------")
avengers.pop()
print("avengers =", avengers)





