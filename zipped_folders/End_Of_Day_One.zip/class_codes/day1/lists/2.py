avengers = ["ironman", "hawkeye", "black widow", "thor"]
print(type(avengers))

list_num = [23, 43, 12,      67, 55]
print(type(list_num))
