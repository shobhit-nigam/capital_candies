avengers = ["ironman", "hawkeye", "black widow", "thor"]
print(avengers)
print(avengers[2])
print(avengers[-2])
print(avengers[2:3])





