avengers = ["ironman", "hawkeye", "black widow", "thor"]

print("avengers =", avengers)
print("-------")
avengers.append("Dr Strange")
avengers[1] = "hulk"

print("avengers =", avengers)





