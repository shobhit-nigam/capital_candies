# functions
avengers = ["ironman", "hawkeye", "Dr Strange", "black widow", "thor"]

print("avengers =", avengers)
print("-------")
avengers.clear()
print("avengers =", avengers)





