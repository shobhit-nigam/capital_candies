# slice

stra = "captain"
str_sliced = stra[1:4]

print("stra =", stra)

print("str_sliced =", str_sliced)
# [0:3]
print("stra[:] =", stra[:])
# start at 3, go till the end, include the end

