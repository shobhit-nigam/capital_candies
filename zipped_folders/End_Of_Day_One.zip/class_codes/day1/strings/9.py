# str functions

stra = "hulk"

print(stra.upper())

