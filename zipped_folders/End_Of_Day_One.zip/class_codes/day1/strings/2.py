# index

stra = "captain america"
strb = ["captain", "america"]

print("stra =", stra)
print("stra[3] =", stra[3])
print("stra[-3] =", stra[-3])
print("stra[-1] =", stra[-1])
