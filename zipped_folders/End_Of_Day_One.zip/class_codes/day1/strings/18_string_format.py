# str functions

state = "new mexico\texas"
print(state)

state = r"new mexico\texas\t"
print(state)

