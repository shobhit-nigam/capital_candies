# slice
# step
stra = "captain"
str_sliced = stra[0:8:2]

print("stra =", stra)

print("stra[0:8:2] =", stra[0:8:2])
print("stra[::2] =", stra[::2])
print("stra[::-1] =", stra[::-1])
# ######
print("stra[::-1] =", stra[::-2])


