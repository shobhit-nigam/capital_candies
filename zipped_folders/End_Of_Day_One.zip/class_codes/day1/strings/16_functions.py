# str functions

stra = "captain"
print("stra =", stra)
print("stra.upper() =",stra.upper())
print("stra =", stra)

# re assign
stra = stra.upper()



