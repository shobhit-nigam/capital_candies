# str functions

stra = "captain marvel is apt to be a hero"

print(stra.count('ap'))
print("captain marvel".count('ap'))

