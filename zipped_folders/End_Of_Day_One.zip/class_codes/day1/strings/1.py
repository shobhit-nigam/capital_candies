# double or single

stra = "captain"
print("stra =", stra)
strb = 'thor'
print("strb =", strb)


# error 
#strc = "ironman'
print("strc =", strc)
