# str functions

stra = "avengers essemble"

print(stra.capitalize())
print(stra.title())
print(stra.upper())
print(stra.lower())

