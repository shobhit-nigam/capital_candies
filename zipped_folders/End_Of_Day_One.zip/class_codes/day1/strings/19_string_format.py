name = "beth"
incentive = 12

print(name, "gets a", incentive, "percent incentive")

# newer style
print(f"{name} gets a {incentive} percent incentive")

# older style
print("{} gets a {} percent incentive".format(name, incentive))
