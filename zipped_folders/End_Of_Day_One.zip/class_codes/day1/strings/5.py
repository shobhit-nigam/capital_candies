# slice

stra = "captain"

print("stra =", stra)

print("stra[:3] =", stra[:3])
# [0:3]
print("stra[3:] =", stra[3:])
# start at 3, go till the end, include the end
