# slice

stra = "captain"

print("stra =", stra)

print("stra[1:5] =", stra[1:5])
print("stra[0:3] =", stra[0:3])
