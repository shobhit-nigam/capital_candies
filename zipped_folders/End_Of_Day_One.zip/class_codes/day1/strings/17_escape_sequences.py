# str functions

state = "new mexico\texas"
print(state)


state = "new mexico\\texas"
print(state)

food = 'i want to try "menudo"'
print(food)
food = "i want to try \"menudo\""
print(food)
#error
food = "i want to try "menudo""

