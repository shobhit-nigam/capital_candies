# str functions

ia = 234            # int
stra = "234"        # string
strb = "EDR3410xyt" # string
strc = "WQEryu"     # string
strd = "EDR2467vyr" 


"""
>>> stra.isalpha()
False
>>> strb.isalpha()
False
>>> strb.isalnum()
True
>>> strb.isdigit()
False
>>> stra.isdigit()
True
strb[3:7].isdigit()
"""
