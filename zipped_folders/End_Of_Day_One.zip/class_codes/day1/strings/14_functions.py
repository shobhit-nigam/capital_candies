# str functions

stra = "captain marvel is apt to be a hero"

print(stra.index('r'))
print(stra.rindex('r'))


