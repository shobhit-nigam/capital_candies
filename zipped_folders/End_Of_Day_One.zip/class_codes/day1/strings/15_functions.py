# str functions

stra = "captain"
print(stra[0])

# error
stra[0] = 'C'

stra = "ironman"


