# slice
# out of range

stra = "captain"
str_sliced = stra[3:18]

print("stra =", stra)

print("stra[3:18] =", stra[3:18])



