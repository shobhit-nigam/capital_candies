# index

stra = "captain"

print("stra =", stra)
print("stra[3] =", stra[3])
print("stra[-3] =", stra[-3])


# error 
print("stra[11] =", stra[11])
